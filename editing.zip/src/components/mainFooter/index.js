export default {
  name: 'ComponentsMainFooter',
  data () {
    return {
    }
  },
  methods: {
  },
  created () {},
  mounted () {}
}
