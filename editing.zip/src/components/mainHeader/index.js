export default {
  name: 'ComponentsMainHeader',
  data () {
    return {
    }
  },
  methods: {
  },
  created () {},
  mounted () {}
}
