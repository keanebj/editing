export default {
  name: 'ComponentsMainMenu',
  props: {
    data: Array,
    onSelect: Function,
    menuKey: {
      type: String,
      default: ''
    }
  },
  methods: {
  },
  created() { },
  mounted() { }
}
