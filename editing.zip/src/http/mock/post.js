exports.path = '/api/post'
exports.type = 'post'
exports.export = function (req, res) {
  return {
    b: 333
  }
}
