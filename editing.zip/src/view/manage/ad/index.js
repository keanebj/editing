export default {
  name: 'ViewManageAd',
  data () {
    return {
    }
  },
  methods: {
  },
  created () {},
  mounted () {}
}
