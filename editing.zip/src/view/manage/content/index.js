export default {
  name: 'ViewManageContent',
  data () {
    return {
    }
  },
  methods: {
  },
  created () {},
  mounted () {}
}
