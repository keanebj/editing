export default {
  name: 'ViewManageStudio',
  data () {
    return {
    }
  },
  methods: {
  },
  created () {},
  mounted () {}
}
