export default {
  name: 'ViewManageStudioId',
  data () {
    return {
      form: {}
    }
  },
  methods: {
  },
  created () {},
  mounted () {}
}
